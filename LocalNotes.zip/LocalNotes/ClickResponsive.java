public interface ClickResponsive {
    public void onMouseClicked();
    public void onMouseReleased();
}
