public interface RightClickResponsive {
    public void onRightMouseClicked();
    public void onRightMouseReleased();
}
