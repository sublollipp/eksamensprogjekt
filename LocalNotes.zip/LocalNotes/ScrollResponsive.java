public interface ScrollResponsive {
    void onScroll(float scrollAmount);
}
