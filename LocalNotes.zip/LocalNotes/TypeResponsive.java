public interface TypeResponsive {
    public void keyPressed();
}
